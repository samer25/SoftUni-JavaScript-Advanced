function attachGradientEvents() {
    console.log('TODO:...');
}